# billing_software using pure python with libraries like tkinter 
